//Alondra Paulino Santos
//Airgead Banking
//April 5, 2025

#include <iostream>
#include <limits>
#include "InvestmentCalculator.h" 
using namespace std;

int main() {
    // Variables to store user input
    double initialInvestment;
    double monthlyDeposit;
    double annualInterest;
    int numberOfYears;
    string choice;

    // Create an object of the InvestmentCalculator class
    InvestmentCalculator calc;

    while (true) {
        // Prompt the user for investment details
        cout << "\n************************************\n";
        cout << "********** Data Input **************\n";

        cout << "Initial Investment Amount: $";
        while (!(cin >> initialInvestment) || initialInvestment < 0) {
            cout << "Invalid input. Please enter a positive number: $";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }

        cout << "Monthly Deposit: $";
        while (!(cin >> monthlyDeposit) || monthlyDeposit < 0) {
            cout << "Invalid input. Please enter a positive number: $";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }

        cout << "Annual Interest: %";
        while (!(cin >> annualInterest) || annualInterest < 0) {
            cout << "Invalid input. Please enter a positive number: %";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }

        cout << "Number of years: ";
        while (!(cin >> numberOfYears) || numberOfYears <= 0) {
            cout << "Invalid input. Please enter a positive whole number: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }

        // Store the user input inside the object
        calc.setUserData(initialInvestment, monthlyDeposit, annualInterest, numberOfYears);

        // Pause before displaying results
        cout << "\nPress any key to continue...";
        cin.ignore();
        cin.get();

        // Show report without monthly deposits
        calc.calculateBalanceWithoutMonthlyDeposit(initialInvestment, annualInterest, numberOfYears);

        // Pause again
        cout << "\nPress any key to continue...";
        cin.get();

        // Show report with monthly deposits
        calc.balanceWithMonthlyDeposit(initialInvestment, monthlyDeposit, annualInterest, numberOfYears);

        // Ask if the user wants to run another calculation
        while (true) {
            cout << "\nWould you like to try again? (Y/N or Yes/No): ";
            cin >> choice;

            // Convert input to lowercase
            for (char& c : choice) {
                c = tolower(c);
            }

            if (choice == "y" || choice == "yes") {
                break; // loop again
            }
            else if (choice == "n" || choice == "no") {
                cout << "\nThank you for using Airgead Banking App!\n";
                return 0; // exit program
            }
            else {
                cout << "Invalid input. Please try again.\n";
            }
        }
    }
}