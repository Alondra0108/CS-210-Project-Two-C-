//Alondra Paulino Santos
//Airgead Banking
//April 5, 2025

#include <iostream>
#include <iomanip>
#include "InvestmentCalculator.h"
using namespace std;

// Stores user input into member variables
void InvestmentCalculator::setUserData(double t_initial, double t_monthly, double t_interest, int t_years) {
    m_initialInvestment = t_initial;
    m_monthlyDeposit = t_monthly;
    m_annualInterest = t_interest;
    m_numberOfYears = t_years;
}

// Prints a formatted line showing the year, balance, and interest
void InvestmentCalculator::printDetails(int year, double yearEndBalance, double interestEarned) {
    cout << fixed << setprecision(2);
    cout << fixed << setw(4) << year
        << fixed << setw(16) << "$" << setw(8) << yearEndBalance
        << fixed << setw(16) << "$" << setw(8) << interestEarned
        << endl;
}

// Calculates balance and interest without monthly deposits
double InvestmentCalculator::calculateBalanceWithoutMonthlyDeposit(double initialInvestment, double interestRate, int numberOfYears) {
    double balance = initialInvestment;
    double yearlyInterest = 0.0;
    double monthlyRate = (interestRate / 100.0) / 12.0;
    double monthlyInterest = 0.0;

    // Display report header
    cout << fixed << setprecision(2);
    cout << "\n  Balance and Interest Without Additional Monthly Deposits\n";
    cout << "===========================================================\n";
    cout << "  Year\t\tYear End Balance\tEarned Interest\n";
    cout << "-----------------------------------------------------------\n";

    for (int year = 1; year <= numberOfYears; ++year) {
        yearlyInterest = 0.0;

        for (int month = 1; month <= 12; ++month) {
            // Calculate monthly interest
            monthlyInterest = balance * monthlyRate;
            balance += monthlyInterest;              // Add interest to balance
            yearlyInterest += monthlyInterest;       // Track interest for the year
        }

        // Print final result for the year
        printDetails(year, balance, yearlyInterest);
    }

    return balance;
}

// Calculates balance and interest with monthly deposits
double InvestmentCalculator::balanceWithMonthlyDeposit(double initialInvestment, double monthlyDeposit, double interestRate, int numberOfYears) {
    double balance = initialInvestment;
    double yearlyInterest = 0.0;
    double monthlyRate = (interestRate / 100.0) / 12.0;
    double monthlyInterest = 0.0;

    // Display report header
    cout << fixed << setprecision(2);
    cout << "\n  Balance and Interest With Additional Monthly Deposits\n";
    cout << "========================================================\n";
    cout << "  Year\t\tYear End Balance\tEarned Interest\n";
    cout << "--------------------------------------------------------\n";

    for (int year = 1; year <= numberOfYears; ++year) {
        yearlyInterest = 0.0;

        for (int month = 1; month <= 12; ++month) {
            // Add monthly deposit before calculating interest
            balance += monthlyDeposit;

            // Calculate interest after deposit is added
            monthlyInterest = balance * monthlyRate;
            balance += monthlyInterest;
            yearlyInterest += monthlyInterest;
        }

        printDetails(year, balance, yearlyInterest);
    }

    return balance;
}


