//Alondra Paulino Santos
//Airgead Banking
//April 5, 2025

#ifndef INVESTMENTCALCULATOR_H
#define INVESTMENTCALCULATOR_H

#include <iomanip>
#include <iostream>
using namespace std;

class InvestmentCalculator {
private:
    // Member variables to store input values
    double m_initialInvestment;
    double m_monthlyDeposit;
    double m_annualInterest;
    int m_numberOfYears;

public:
    // Sets all user-provided investment parameters
    void setUserData(double t_initial, double t_monthly, double t_interest, int t_years);

    // Prints a single line of the report with formatting
    void printDetails(int year, double yearEndBalance, double interestEarned);

    // Calculates yearly balances without monthly deposits
    double calculateBalanceWithoutMonthlyDeposit(double initialInvestment, double interestRate, int numberOfYears);

    // Calculates yearly balances with monthly deposits
    double balanceWithMonthlyDeposit(double initialInvestment, double monthlyDeposit, double interestRate, int numberOfYears);
};

#endif
